package com.personal.smartmoneyai

import com.personal.smartmoneyai.model.*
import com.personal.smartmoneyai.smc.SmcEngine
import com.personal.smartmoneyai.vision.*
import org.junit.Assert.*
import org.junit.Test
import java.util.Random
import kotlin.math.abs

class SmcEngineTest {
    /** Down-trend -> sell-side sweep -> displacement/CHoCH -> retrace into OB/FVG -> bullish confirmation. */
    private fun bullishSetup(): List<Candle> {
        val out = mutableListOf<Candle>()
        var prev = 125.0
        fun add(t: Double, w: Double = 0.3) { val o = prev; out += Candle(out.size, o, maxOf(o, t) + w, minOf(o, t) - w, t); prev = t }
        for (i in 1..10) add(125.0 - 1.5 * i)
        for (i in 1..5) add(110.0 + 1.4 * i)
        for (i in 1..10) add(117.0 - 1.2 * i)
        for (i in 1..5) add(105.0 + i)
        for (i in 1..4) add(110.0 - i)
        out += Candle(out.size, 107.2, 107.5, 105.7, 106.0)
        out += Candle(out.size, 105.8, 106.9, 104.2, 106.6)
        add(112.8, 0.2); add(114.0, 0.2)
        add(112.6, 0.3); add(111.0, 0.3); add(109.4, 0.3); add(108.0, 0.3)
        out += Candle(out.size, 107.9, 109.2, 107.3, 108.9)
        return out
    }

    private fun chart(c: List<Candle>) = ChartData(c, "BTC/USDT", "15M", 1.0, emptyList())

    @Test fun bullishSetupGivesBuyWithRealisticLevels() {
        val r = SmcEngine().analyze(chart(bullishSetup()))
        assertEquals(Decision.BUY, r.decision)
        assertTrue(r.score >= 75)
        assertTrue(r.stopLoss!! < r.entryLow!!)
        assertTrue(r.takeProfit1!! > r.entryHigh!!)
        assertTrue(r.riskReward!! >= 1.5)
        assertEquals(0, r.breakdown["Higher Timeframe Alignment"])   // never faked from one chart
    }

    @Test fun mirroredSetupGivesSell() {
        val m = bullishSetup().map { Candle(it.index, 240 - it.open, 240 - it.low, 240 - it.high, 240 - it.close) }
        assertEquals(Decision.SELL, SmcEngine().analyze(chart(m)).decision)
    }

    @Test fun tooFewCandlesIsUnable() {
        assertEquals(Decision.UNABLE, SmcEngine().analyze(chart(bullishSetup().take(10))).decision)
    }

    @Test fun noiseIsOverwhelminglyWait() {
        val rnd = Random(7); var signals = 0
        repeat(200) {
            var p = 100.0
            val cs = (0 until 80).map { i ->
                val o = p; p += rnd.nextGaussian(); Candle(i, o, maxOf(o, p) + rnd.nextDouble() * .5, minOf(o, p) - rnd.nextDouble() * .5, p)
            }
            if (SmcEngine().analyze(chart(cs)).decision.let { it == Decision.BUY || it == Decision.SELL }) signals++
        }
        assertTrue("signals on noise: $signals/200", signals <= 8)
    }

    @Test fun pixelRoundTripRecoversPrices() {
        val c = bullishSetup()
        val W = 800; val H = 1000
        val px = IntArray(W * H) { 0xFF0B0D10.toInt() }
        val lo = c.minOf { it.low } - 2; val hi = c.maxOf { it.high } + 2
        fun yOf(p: Double) = (hi - p) / (hi - lo) * (H - 100) + 50
        c.forEachIndexed { i, k ->
            val xc = 20 + i * 14; val col = if (k.bullish) 0xFF089981.toInt() else 0xFFF23645.toInt()
            for (y in yOf(k.high).toInt()..yOf(k.low).toInt()) px[y * W + xc + 4] = col
            val bt = yOf(maxOf(k.open, k.close)).toInt(); val bb = yOf(minOf(k.open, k.close)).toInt()
            for (y in bt..maxOf(bt + 1, bb)) for (x in xc..xc + 8) px[y * W + x] = col
        }
        val ex = CandleExtractor.extract(px, W, H, 0, 700) as Extraction.Ok
        assertEquals(c.size, ex.candles.size)
        val fit = AxisFit.fit((0..5).map { j -> val p = lo + (hi - lo) * j / 5; AxisLabel(yOf(p), p) })!!
        ex.candles.forEachIndexed { i, r -> assertEquals(c[i].high, fit.price(r.wickTop.toDouble()), 0.2) }
    }

    @Test fun priceAndHeaderParsing() {
        assertEquals(87500.0, PriceText.parse("87,500.00")!!, 1e-9)
        assertEquals(87500.0, PriceText.parse("87.500,00")!!, 1e-9)
        assertNull(PriceText.parse("BTC"))
        assertEquals("15M", HeaderParser.timeframe(listOf("BTCUSDT · 15 · BINANCE")))
        assertEquals("BTC/USDT", HeaderParser.market(listOf("BTCUSDT · 15 · BINANCE")))
        assertNull(HeaderParser.timeframe(listOf("15m 1h 4h 1D")))  // ambiguous tabs => unknown, never guessed
    }
}
