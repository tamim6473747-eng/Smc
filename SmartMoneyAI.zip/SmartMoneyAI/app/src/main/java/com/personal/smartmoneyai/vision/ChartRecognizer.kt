package com.personal.smartmoneyai.vision

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.personal.smartmoneyai.model.Candle
import com.personal.smartmoneyai.model.ChartData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

sealed class Recognition {
    data class Success(val chart: ChartData) : Recognition()
    data class Failure(val reason: String) : Recognition()
}

/**
 * Extension point: swap in a TFLite / cloud vision recogniser later by implementing this
 * interface and changing one line in ScannerService. The SMC engine only sees [ChartData].
 */
interface ChartRecognizer {
    suspend fun recognize(bitmap: Bitmap): Recognition
}

/** Local, offline, key-free recogniser: pixel colour analysis + on-device ML Kit OCR. */
class PixelChartRecognizer : ChartRecognizer {

    private val ocr by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private data class OcrLine(val text: String, val box: Rect)

    override suspend fun recognize(bitmap: Bitmap): Recognition = withContext(Dispatchers.Default) {
        val w = bitmap.width; val h = bitmap.height
        val lines = try {
            ocr.process(InputImage.fromBitmap(bitmap, 0)).await().textBlocks
                .flatMap { it.lines }.mapNotNull { l -> l.boundingBox?.let { OcrLine(l.text, it) } }
        } catch (e: Exception) {
            return@withContext Recognition.Failure("Text recognition failed: ${e.message}")
        }

        // ---- price axis: numeric labels sharing a left edge in the right 40% of the screen ----
        val numeric = lines.mapNotNull { l ->
            val v = PriceText.parse(l.text) ?: return@mapNotNull null
            if (l.box.centerX() < w * 0.6) null else Triple(l, v, l.box)
        }
        val bucket = (w * 0.025).coerceAtLeast(8.0)
        val best = numeric.groupBy { (it.third.left / bucket).roundToInt() }
            .maxByOrNull { it.value.size }?.value
        if (best == null || best.size < 3) {
            return@withContext Recognition.Failure("Price axis not readable (need 3+ labels on the right edge).")
        }
        val axis = AxisFit.fit(best.map { AxisLabel(it.third.centerY().toDouble(), it.second) })
            ?: return@withContext Recognition.Failure("Price axis is not linear or was misread (log scale?).")
        val axisLeft = best.minOf { it.third.left } - 4

        // ---- candles ----
        val px = IntArray(w * h)
        bitmap.getPixels(px, 0, w, 0, 0, w, h)
        val ext = CandleExtractor.extract(px, w, h, 0, axisLeft.coerceIn(10, w - 1))
        val ok = when (ext) {
            is Extraction.Fail -> return@withContext Recognition.Failure(ext.reason)
            is Extraction.Ok -> ext
        }

        val candles = ok.candles.mapIndexed { i, r ->
            val high = axis.price(r.wickTop.toDouble())
            val low = axis.price(r.wickBottom.toDouble())
            val topP = axis.price(r.bodyTop.toDouble())
            val botP = axis.price(r.bodyBottom.toDouble())
            Candle(i, if (r.bull) botP else topP, high, low, if (r.bull) topP else botP)
        }

        // ---- header (market / timeframe) from top part of screen only ----
        val header = HeaderParser.parse(lines.filter { it.box.centerY() < h * 0.22 }.map { it.text })

        val notes = ok.notes + "Axis fit: ${axis.labelsUsed} labels, max error ${"%.1f".format(axis.maxResidualPx)} px"
        val conf = (1.0 - axis.maxResidualPx / 6.0).coerceIn(0.3, 1.0)
        Recognition.Success(ChartData(candles, header.market, header.timeframe, conf, notes))
    }
}
