package com.personal.smartmoneyai.overlay

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.personal.smartmoneyai.R
import com.personal.smartmoneyai.ScanState
import kotlin.math.abs

private class RingView(ctx: Context) : View(ctx) {
    var ringColor = 0xFF8A94A3.toInt()
    var spinning = false
        set(v) { field = v; if (v) anim.start() else { anim.cancel(); invalidate() } }
    private var angle = 0f
    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 900; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { angle = it.animatedValue as Float; invalidate() }
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF14181D.toInt() }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4f * ctx.resources.displayMetrics.density; strokeCap = Paint.Cap.ROUND }
    private val icon = ContextCompat.getDrawable(ctx, R.drawable.ic_scanner)!!.mutate()

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = width / 2f - stroke.strokeWidth
        c.drawCircle(cx, cy, width / 2f - 1f, fill)
        stroke.color = ringColor
        val rect = RectF(cx - r, cy - r, cx + r, cy + r)
        if (spinning) c.drawArc(rect, angle, 100f, false, stroke) else c.drawCircle(cx, cy, r, stroke)
        val s = (width * 0.42f).toInt()
        icon.setTint(ringColor)
        icon.setBounds((cx - s / 2).toInt(), (cy - s / 2).toInt(), (cx + s / 2).toInt(), (cy + s / 2).toInt())
        icon.draw(c)
    }
}

/** Draggable always-on-top scanner button. Tap = scan, long-press = hide (reopen from notification/app). */
class FloatingButton(
    private val ctx: Context,
    private val onTap: () -> Unit,
    private val onLongPress: () -> Unit,
    private val onMoved: (Int, Int) -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val d = ctx.resources.displayMetrics.density
    private val ring = RingView(ctx)
    private val label = TextView(ctx).apply {
        textSize = 10f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding((8 * d).toInt(), (2 * d).toInt(), (8 * d).toInt(), (2 * d).toInt())
        background = GradientDrawable().apply { cornerRadius = 20 * d; setColor(0xE614181D.toInt()) }
        visibility = View.GONE
    }
    private val root = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
        addView(ring, LinearLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt()))
        addView(label, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (3 * d).toInt() })
    }
    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

    var shown = false
        private set

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouch() {
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var moved = false; var longFired = false
        val lpRunnable = Runnable { if (!moved) { longFired = true; onLongPress() } }
        root.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y
                    moved = false; longFired = false
                    v.postDelayed(lpRunnable, 700)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!moved && (abs(dx) > 10 * d || abs(dy) > 10 * d)) { moved = true; v.removeCallbacks(lpRunnable) }
                    if (moved) { lp.x = (startX + dx).toInt(); lp.y = (startY + dy).toInt(); if (shown) wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> {
                    v.removeCallbacks(lpRunnable)
                    if (moved) onMoved(lp.x, lp.y) else if (!longFired) onTap()
                }
                MotionEvent.ACTION_CANCEL -> v.removeCallbacks(lpRunnable)
            }
            true
        }
    }

    fun show(x: Int, y: Int) {
        if (shown) return
        lp.x = x; lp.y = y
        attachTouch()
        wm.addView(root, lp)
        shown = true
        root.visibility = View.VISIBLE
    }

    fun hide() {
        if (!shown) return
        try { wm.removeView(root) } catch (_: Exception) {}
        shown = false
    }

    fun moveTo(x: Int, y: Int) {
        if (lp.x == x && lp.y == y) return
        lp.x = x; lp.y = y
        if (shown) wm.updateViewLayout(root, lp)
    }

    /** Invisible (but still attached) so it doesn't appear in the screenshot. */
    fun setInvisibleForCapture(invisible: Boolean) {
        root.visibility = if (invisible) View.INVISIBLE else View.VISIBLE
    }

    fun render(state: ScanState, decisionColor: Int? = null) {
        val (color, text, spin) = when (state) {
            ScanState.IDLE -> Triple(0xFFB8C0CC.toInt(), "", false)
            ScanState.SCANNING -> Triple(0xFF4FC3F7.toInt(), "SCANNING…", true)
            ScanState.ANALYZING -> Triple(0xFFFFB74D.toInt(), "ANALYZING…", true)
            ScanState.SIGNAL_FOUND -> Triple(decisionColor ?: 0xFF2BD576.toInt(), "SIGNAL FOUND", false)
            ScanState.WAIT -> Triple(0xFFFFD54F.toInt(), "WAIT", false)
        }
        ring.ringColor = color
        ring.spinning = spin
        ring.invalidate()
        label.text = text
        label.visibility = if (text.isEmpty()) View.GONE else View.VISIBLE
    }
}
