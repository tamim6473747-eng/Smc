package com.personal.smartmoneyai.capture

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import com.personal.smartmoneyai.service.ScannerService

/**
 * Invisible activity whose only job is to show the system "start recording/casting" consent
 * dialog, then hand the grant to ScannerService. Launched from the dashboard (START SCANNER)
 * and from the service if the grant ever expires.
 */
class CapturePermissionActivity : Activity() {
    private val REQ = 4711

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScannerService::class.java)
                    .setAction(ScannerService.ACTION_START)
                    .putExtra(ScannerService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(ScannerService.EXTRA_DATA, data)
                startForegroundService(i)
            } else {
                startService(Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_PERMISSION_DENIED))
            }
        }
        finish()
    }
}
