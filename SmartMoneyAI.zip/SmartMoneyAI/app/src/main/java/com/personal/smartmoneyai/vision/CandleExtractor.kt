package com.personal.smartmoneyai.vision

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/** A candle measured in screen pixels (y grows downward). */
data class RawCandle(
    val x0: Int, val x1: Int, val bull: Boolean,
    val wickTop: Int, val wickBottom: Int,
    val bodyTop: Int, val bodyBottom: Int
) {
    val centerX get() = (x0 + x1) / 2.0
    val width get() = x1 - x0 + 1
}

sealed class Extraction {
    data class Ok(val candles: List<RawCandle>, val palette: String, val notes: List<String>) : Extraction()
    data class Fail(val reason: String) : Extraction()
}

/**
 * Pure-Kotlin (no Android classes => unit-testable) candle finder.
 * Method: classify pixels against known bull/bear candle colours, group touching columns into
 * clusters, read wick from the cluster's vertical extent and body from rows that are mostly filled.
 * Limitations (reported, never hidden): needs candles >= 3px wide, one visible price pane works best,
 * merged/overlapping candles cause a deliberate failure instead of a guess.
 */
object CandleExtractor {

    class Palette(val name: String, val bull: Int, val bear: Int)

    val palettes = listOf(
        Palette("TradingView", 0x089981, 0xF23645),
        Palette("TradingView classic", 0x26A69A, 0xEF5350),
        Palette("Binance", 0x0ECB81, 0xF6465D),
        Palette("Bybit", 0x20B26C, 0xEF454A)
    )

    private const val TOL = 30

    private fun near(c: Int, ref: Int): Boolean =
        abs(((c shr 16) and 0xFF) - ((ref shr 16) and 0xFF)) <= TOL &&
            abs(((c shr 8) and 0xFF) - ((ref shr 8) and 0xFF)) <= TOL &&
            abs((c and 0xFF) - (ref and 0xFF)) <= TOL

    private fun genericClass(c: Int): Int {
        val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val b = c and 0xFF
        return when {
            g >= 120 && g > r + 50 && g > b + 10 -> 1
            r >= 150 && r > g + 80 && r > b + 60 -> 2
            else -> 0
        }
    }

    fun extract(px: IntArray, w: Int, h: Int, xFrom: Int = 0, xTo: Int = w - 1): Extraction {
        if (px.size < w * h) return Extraction.Fail("Invalid image buffer.")
        // ---- choose palette by pixel votes ----
        val votes = IntArray(palettes.size)
        for (y in 0 until h) for (x in xFrom..xTo) {
            val c = px[y * w + x]
            for (i in palettes.indices) if (near(c, palettes[i].bull) || near(c, palettes[i].bear)) votes[i]++
        }
        val bestIdx = votes.indices.maxByOrNull { votes[it] } ?: 0
        val usePalette = votes[bestIdx] >= 300
        val paletteName = if (usePalette) palettes[bestIdx].name else "generic red/green"

        val cls = ByteArray(w * h)
        for (y in 0 until h) for (x in xFrom..xTo) {
            val c = px[y * w + x]
            cls[y * w + x] = if (usePalette) {
                val p = palettes[bestIdx]
                when { near(c, p.bull) -> 1; near(c, p.bear) -> 2; else -> 0 }
            } else genericClass(c).toByte()
        }

        // ---- remove horizontal lines (current-price line, grid in candle colour) ----
        val regionW = xTo - xFrom + 1
        for (y in 0 until h) {
            var n1 = 0; var n2 = 0
            for (x in xFrom..xTo) when (cls[y * w + x].toInt()) { 1 -> n1++; 2 -> n2++ }
            if (n1 > 0.35 * regionW) for (x in xFrom..xTo) if (cls[y * w + x].toInt() == 1) cls[y * w + x] = 0
            if (n2 > 0.35 * regionW) for (x in xFrom..xTo) if (cls[y * w + x].toInt() == 2) cls[y * w + x] = 0
        }

        // ---- column clusters per colour ----
        val raw = mutableListOf<RawCandle>()
        for (color in 1..2) {
            val has = BooleanArray(w)
            for (x in xFrom..xTo) for (y in 0 until h) if (cls[y * w + x].toInt() == color) { has[x] = true; break }
            var x = xFrom
            while (x <= xTo) {
                if (!has[x]) { x++; continue }
                val x0 = x
                while (x <= xTo && has[x]) x++
                val x1 = x - 1
                val wd = x1 - x0 + 1
                var top = Int.MAX_VALUE; var bottom = -1
                val rowCount = IntArray(h)
                for (yy in 0 until h) for (xx in x0..x1) if (cls[yy * w + xx].toInt() == color) {
                    rowCount[yy]++
                    if (yy < top) top = yy
                    if (yy > bottom) bottom = yy
                }
                if (bottom - top + 1 < 3) continue
                val thr = max(2, (0.6 * wd).roundToInt())
                var bt = -1; var bb = -1
                for (yy in top..bottom) if (rowCount[yy] >= thr) { if (bt < 0) bt = yy; bb = yy }
                if (bt < 0) { bt = (top + bottom) / 2; bb = bt }
                raw += RawCandle(x0, x1, color == 1, top, bottom, bt, bb)
            }
        }
        if (raw.size < 10) return Extraction.Fail("Too few candles detected (${raw.size}). Make sure a candlestick chart is visible.")

        val notes = mutableListOf("Candle colours: $paletteName")
        val widths = raw.map { it.width }.sorted()
        val medW = widths[widths.size / 2]
        if (medW < 3) return Extraction.Fail("Candles are too thin to read ($medW px). Zoom the chart in.")

        // ---- drop wide blobs (labels, buttons, merged candles) ----
        var cs = raw.filter { it.width <= 2.5 * medW }
        if (cs.size < raw.size) notes += "Ignored ${raw.size - cs.size} non-candle shapes."

        // ---- drop volume bars: many clusters sharing exactly the same bottom row ----
        val groups = cs.groupBy { it.wickBottom }
        val volRows = groups.filter { it.value.size >= max(8, (0.3 * cs.size).toInt()) }.keys
        if (volRows.isNotEmpty()) {
            val before = cs.size
            cs = cs.filter { it.wickBottom !in volRows }
            notes += "Separated ${before - cs.size} volume bars."
        }
        cs = cs.sortedBy { it.x0 }
        if (cs.size < 20) return Extraction.Fail("Only ${cs.size} candles readable (need 20+).")

        // ---- sequence sanity: consistent spacing, no missing candles ----
        val spacing = cs.zipWithNext { a, b -> b.centerX - a.centerX }
        val medSp = spacing.sorted()[spacing.size / 2]
        if (medSp < 2) return Extraction.Fail("Candles overlap too much to separate. Zoom in.")
        val gaps = spacing.count { it > 1.6 * medSp }
        val tooClose = spacing.count { it < 0.5 * medSp }
        if (gaps > 0 || tooClose > 0) {
            return Extraction.Fail("Candle sequence is irregular ($gaps gaps, $tooClose overlaps) — indicators or merged candles are interfering.")
        }
        return Extraction.Ok(cs, paletteName, notes)
    }
}
