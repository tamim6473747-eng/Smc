package com.personal.smartmoneyai.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("smartmoney_settings")

data class Settings(
    val minScore: Int = 75,
    val timeframe: String = "15M",
    val notifyWait: Boolean = true,
    val sound: Boolean = true,
    val cooldownMin: Int = 5,
    val btnX: Int = -1,
    val btnY: Int = -1
)

class SettingsStore(private val ctx: Context) {
    private object K {
        val minScore = intPreferencesKey("minScore")
        val tf = stringPreferencesKey("tf")
        val notifyWait = booleanPreferencesKey("notifyWait")
        val sound = booleanPreferencesKey("sound")
        val cooldown = intPreferencesKey("cooldown")
        val x = intPreferencesKey("btnX")
        val y = intPreferencesKey("btnY")
    }

    val flow: Flow<Settings> = ctx.dataStore.data.map { p ->
        Settings(
            minScore = p[K.minScore] ?: 75,
            timeframe = p[K.tf] ?: "15M",
            notifyWait = p[K.notifyWait] ?: true,
            sound = p[K.sound] ?: true,
            cooldownMin = p[K.cooldown] ?: 5,
            btnX = p[K.x] ?: -1,
            btnY = p[K.y] ?: -1
        )
    }

    suspend fun update(block: (Settings) -> Settings) {
        ctx.dataStore.edit { p ->
            val cur = Settings(
                p[K.minScore] ?: 75, p[K.tf] ?: "15M", p[K.notifyWait] ?: true, p[K.sound] ?: true,
                p[K.cooldown] ?: 5, p[K.x] ?: -1, p[K.y] ?: -1
            )
            val n = block(cur)
            p[K.minScore] = n.minScore.coerceIn(60, 100)
            p[K.tf] = n.timeframe
            p[K.notifyWait] = n.notifyWait
            p[K.sound] = n.sound
            p[K.cooldown] = n.cooldownMin.coerceIn(0, 120)
            p[K.x] = n.btnX
            p[K.y] = n.btnY
        }
    }
}
