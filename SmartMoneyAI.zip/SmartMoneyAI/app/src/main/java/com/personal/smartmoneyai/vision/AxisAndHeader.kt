package com.personal.smartmoneyai.vision

import kotlin.math.abs

data class AxisLabel(val y: Double, val value: Double)

/** Linear mapping pixel-y -> price, fitted from OCR'd axis labels. */
class AxisFit(val a: Double, val b: Double, val maxResidualPx: Double, val labelsUsed: Int) {
    fun price(y: Double) = a * y + b

    companion object {
        /** Least squares; drops the worst outlier up to twice. Null if the axis can't be trusted. */
        fun fit(labels: List<AxisLabel>): AxisFit? {
            var pts = labels
            repeat(3) {
                if (pts.size < 3) return null
                val n = pts.size.toDouble()
                val sx = pts.sumOf { it.y }; val sy = pts.sumOf { it.value }
                val sxx = pts.sumOf { it.y * it.y }; val sxy = pts.sumOf { it.y * it.value }
                val den = n * sxx - sx * sx
                if (den == 0.0) return null
                val a = (n * sxy - sx * sy) / den
                val b = (sy - a * sx) / n
                if (a >= 0) return null // price must fall as y grows
                val res = pts.map { abs((a * it.y + b) - it.value) / abs(a) }
                val worst = res.indices.maxByOrNull { res[it] }!!
                if (res[worst] <= 3.0) return AxisFit(a, b, res[worst], pts.size)
                pts = pts.filterIndexed { i, _ -> i != worst }
            }
            return null // not linear (log scale?) or OCR misread
        }
    }
}

object PriceText {
    /** Parses "87,500.00", "87.500,00", "0.00001234", "1 234.5". Returns null for anything with letters. */
    fun parse(raw: String): Double? {
        val t = raw.trim().replace(" ", "").replace(" ", "")
        if (t.isEmpty() || !t.all { it.isDigit() || it == ',' || it == '.' }) return null
        if (!t.any { it.isDigit() }) return null
        val lastDot = t.lastIndexOf('.'); val lastComma = t.lastIndexOf(',')
        val norm = when {
            lastDot >= 0 && lastComma >= 0 ->
                if (lastDot > lastComma) t.replace(",", "") else t.replace(".", "").replace(',', '.')
            lastComma >= 0 ->
                if (Regex("^\\d{1,3}(,\\d{3})+$").matches(t)) t.replace(",", "") else t.replace(',', '.')
            else -> t
        }
        return norm.toDoubleOrNull()
    }
}

object HeaderParser {
    data class Header(val market: String?, val timeframe: String?)

    private val quotes = listOf("USDT", "USDC", "BUSD", "USD", "EUR", "GBP", "JPY", "BTC", "ETH")

    fun parse(lines: List<String>): Header = Header(market(lines), timeframe(lines))

    fun market(lines: List<String>): String? {
        for (l in lines) {
            Regex("\\b([A-Z0-9]{2,10})\\s?/\\s?([A-Z]{3,6})\\b").find(l)?.let { return "${it.groupValues[1]}/${it.groupValues[2]}" }
        }
        for (l in lines) for (tok in l.split(Regex("[\\s·•|,]+"))) {
            val t = tok.removeSuffix(".P")
            if (t.length in 6..12 && t.all { it.isUpperCase() || it.isDigit() }) {
                val q = quotes.firstOrNull { t.endsWith(it) && t.length > it.length + 1 }
                if (q != null) return "${t.removeSuffix(q)}/$q"
            }
        }
        return null
    }

    fun timeframe(lines: List<String>): String? {
        // TradingView style: "BTCUSDT · 15 · BINANCE" (bare number = minutes)
        for (l in lines) {
            Regex("[·•|]\\s*(\\d{1,3}|\\d{1,2}[mhHdDwW]|[DWM])\\s*[·•|]").find(l)?.let { m ->
                normalize(m.groupValues[1])?.let { return it }
            }
        }
        // Tab style (Binance etc.): only trust when exactly one distinct token is visible.
        val toks = lines.flatMap { l ->
            Regex("\\b(1|3|5|15|30)m\\b|\\b(1|2|4|6|12)h\\b|\\b1[dDwW]\\b").findAll(l).map { it.value }.toList()
        }.map { normalize(it) }.filterNotNull().toSet()
        return toks.singleOrNull()
    }

    fun normalize(s: String): String? {
        val t = s.trim()
        if (t.all { it.isDigit() }) {
            return when (val m = t.toInt()) {
                1, 3, 5, 15, 30, 45 -> "${m}M"
                60 -> "1H"; 120 -> "2H"; 240 -> "4H"; 360 -> "6H"; 720 -> "12H"
                else -> null
            }
        }
        val num = t.dropLast(1)
        return when (t.last().lowercaseChar()) {
            'm' -> if (t.all { it.isLetter() } || num.isEmpty()) null else "${num}M"
            'h' -> "${num}H"
            'd' -> if (num.isEmpty()) "1D" else "${num}D"
            'w' -> if (num.isEmpty()) "1W" else "${num}W"
            else -> null
        }
    }
}
