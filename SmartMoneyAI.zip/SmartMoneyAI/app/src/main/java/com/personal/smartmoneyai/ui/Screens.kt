package com.personal.smartmoneyai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.personal.smartmoneyai.ScanState
import com.personal.smartmoneyai.ScannerState
import com.personal.smartmoneyai.data.AppDb
import com.personal.smartmoneyai.data.SettingsStore
import com.personal.smartmoneyai.data.Settings
import com.personal.smartmoneyai.data.toResult
import com.personal.smartmoneyai.model.AnalysisResult
import com.personal.smartmoneyai.model.Decision
import com.personal.smartmoneyai.notify.SignalFormatter
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun decisionColor(d: Decision) = when (d) {
    Decision.BUY -> C.buy; Decision.SELL -> C.sell; Decision.WAIT -> C.wait; Decision.UNABLE -> C.muted
}

@Composable
fun AppRoot(
    tick: Int,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onToggleButton: () -> Unit,
    onOpenOverlaySettings: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onRequestNotifications: () -> Unit
) = SmcTheme {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = C.bg,
        bottomBar = {
            NavigationBar(containerColor = C.card) {
                listOf("Dashboard", "History", "Settings").forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Text(listOf("◉", "☰", "⚙")[i], fontSize = 18.sp) },
                        label = { Text(t) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = C.buy, selectedTextColor = C.buy,
                            unselectedIconColor = C.muted, unselectedTextColor = C.muted,
                            indicatorColor = C.line
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize().background(C.bg)) {
            when (tab) {
                0 -> Dashboard(onStart, onStop, onToggleButton)
                1 -> History()
                else -> SettingsScreen(tick, onOpenOverlaySettings, onOpenBatterySettings, onRequestNotifications)
            }
        }
    }
}

@Composable
private fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().background(C.card, RoundedCornerShape(16.dp)).padding(16.dp),
        content = content
    )
}

@Composable
private fun Label(t: String) = Text(t.uppercase(), color = C.muted, fontSize = 11.sp, letterSpacing = 1.2.sp)

@Composable
private fun Dashboard(onStart: () -> Unit, onStop: () -> Unit, onToggle: () -> Unit) {
    val ctx = LocalContext.current
    val running by ScannerState.running.collectAsState()
    val scan by ScannerState.scan.collectAsState()
    val projection by ScannerState.projectionActive.collectAsState()
    val btnVisible by ScannerState.buttonVisible.collectAsState()
    val last by ScannerState.last.collectAsState()
    val message by ScannerState.message.collectAsState()
    val db = remember { AppDb.get(ctx) }
    val history by db.dao().observeAll().collectAsState(initial = emptyList())
    val latestSignal = remember(history) { history.firstOrNull { it.decision == "BUY" || it.decision == "SELL" }?.toResult() }
    val shownLast = last ?: history.firstOrNull()?.toResult()

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SMART MONEY AI", fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
        Text("Personal SMC chart scanner · analysis only, never trades", color = C.muted, fontSize = 12.sp)

        Card {
            Label("Scanner status")
            Spacer(Modifier.height(6.dp))
            val (txt, col) = when {
                !running -> "OFF" to C.muted
                scan == ScanState.SCANNING -> "SCANNING" to C.info
                scan == ScanState.ANALYZING -> "ANALYZING" to C.wait
                scan == ScanState.SIGNAL_FOUND -> "SIGNAL FOUND" to C.buy
                scan == ScanState.WAIT -> "WAIT" to C.wait
                else -> "IDLE · READY" to C.buy
            }
            Text(txt, color = col, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(message, color = C.muted, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(
                "Screen capture: ${if (projection) "authorized" else "not active"}  ·  Floating button: ${if (btnVisible) "visible" else "hidden"}",
                color = C.muted, fontSize = 12.sp
            )
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onStart, enabled = !running, modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = C.buy, contentColor = Color.Black)
                ) { Text("START SCANNER", fontWeight = FontWeight.Bold) }
                OutlinedButton(
                    onClick = onStop, enabled = running, modifier = Modifier.weight(1f),
                    border = BorderStroke(1.dp, if (running) C.sell else C.line)
                ) { Text("STOP SCANNER", color = if (running) C.sell else C.muted, fontWeight = FontWeight.Bold) }
            }
            if (running) {
                TextButton(onClick = onToggle) { Text(if (btnVisible) "Hide floating button" else "Show floating button", color = C.info) }
            }
        }

        Card {
            Label("Last analysis")
            Spacer(Modifier.height(6.dp))
            if (shownLast == null) Text("Nothing scanned yet. Start the scanner, open a chart, tap the floating button.", color = C.muted)
            else ResultBlock(shownLast)
        }

        Card {
            Label("Latest signal")
            Spacer(Modifier.height(6.dp))
            if (latestSignal == null) Text("No BUY/SELL setup has passed the filter yet. WAIT is the normal state.", color = C.muted)
            else ResultBlock(latestSignal)
        }
    }
}

@Composable
private fun ResultBlock(r: AnalysisResult) {
    val col = decisionColor(r.decision)
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm:ss", Locale.getDefault()) }
    Text(SignalFormatter.title(r), color = col, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    Text("${r.market} · ${r.timeframe} · ${fmt.format(Date(r.timestamp))}", color = C.muted, fontSize = 12.sp)
    if (r.decision == Decision.BUY || r.decision == Decision.SELL) {
        Spacer(Modifier.height(8.dp))
        KV("Entry zone", "${SignalFormatter.price(r.entryLow)} – ${SignalFormatter.price(r.entryHigh)}")
        KV("Stop loss", SignalFormatter.price(r.stopLoss))
        KV("Take profit 1", SignalFormatter.price(r.takeProfit1))
        KV("Take profit 2", SignalFormatter.price(r.takeProfit2))
        KV("Risk / reward", "1 : ${String.format(Locale.US, "%.1f", r.riskReward ?: 0.0)}")
        KV("Confluence", "${r.score}/100 · ${r.grade.label}")
        Spacer(Modifier.height(6.dp))
        r.confirmations.forEach { Text("✓ $it", color = C.buy, fontSize = 13.sp) }
    } else {
        Spacer(Modifier.height(6.dp))
        if (r.decision == Decision.WAIT) Text("No high-quality trading setup detected.", fontSize = 13.sp)
        if (r.decision == Decision.UNABLE) Text("UNABLE TO ANALYZE — Please provide a clearer chart.", fontSize = 13.sp)
        r.reasons.distinct().forEach { Text("• $it", color = C.muted, fontSize = 13.sp) }
    }
    if (r.breakdown.isNotEmpty()) {
        Spacer(Modifier.height(8.dp))
        Text(r.breakdown.entries.joinToString("  ·  ") { "${it.key.split(" ").joinToString("") { w -> w.take(1) }} ${it.value}" },
            color = C.muted, fontSize = 11.sp)
    }
}

@Composable
private fun KV(k: String, v: String) = Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween) {
    Text(k, color = C.muted, fontSize = 13.sp)
    Text(v, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
}

@Composable
private fun History() {
    val ctx = LocalContext.current
    val db = remember { AppDb.get(ctx) }
    val items by db.dao().observeAll().collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()
    var open by remember { mutableStateOf<Long?>(null) }
    val fmt = remember { SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("SIGNAL HISTORY", fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            TextButton(onClick = { scope.launch { db.dao().clear() } }, enabled = items.isNotEmpty()) { Text("Clear", color = C.sell) }
        }
        if (items.isEmpty()) Text("No scans yet.", color = C.muted)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(items, key = { it.id }) { e ->
                val r = e.toResult()
                Column(
                    Modifier.fillMaxWidth().background(C.card, RoundedCornerShape(12.dp)).clickable { open = if (open == e.id) null else e.id }.padding(12.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(r.decision.name, color = decisionColor(r.decision), fontWeight = FontWeight.Bold)
                        Text("${r.score}/100", color = C.muted)
                    }
                    Text("${r.market} · ${r.timeframe} · ${fmt.format(Date(r.timestamp))}", color = C.muted, fontSize = 12.sp)
                    if (open == e.id) { Spacer(Modifier.height(8.dp)); ResultBlock(r) }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(tick: Int, onOverlay: () -> Unit, onBattery: () -> Unit, onNotif: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { SettingsStore(ctx) }
    val s by store.flow.collectAsState(initial = Settings())
    val scope = rememberCoroutineScope()
    val projection by ScannerState.projectionActive.collectAsState()
    fun upd(b: (Settings) -> Settings) = scope.launch { store.update(b) }

    val overlayOk = remember(tick) { AndroidSettings.canDrawOverlays(ctx) }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SETTINGS", fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)

        Card {
            Label("Minimum confluence score")
            Text("${s.minScore}/100  (below this → WAIT; 85+ = High-Confluence)", fontSize = 14.sp)
            Slider(value = s.minScore.toFloat(), onValueChange = { v -> upd { it.copy(minScore = v.toInt()) } }, valueRange = 60f..95f, steps = 6)
            Text("Score measures technical confluence, not win probability. One visible chart cannot score higher-timeframe alignment, so its maximum is 85.", color = C.muted, fontSize = 11.sp)
        }
        Card {
            Label("Preferred timeframe (used only if the chart doesn't show it)")
            Spacer(Modifier.height(6.dp))
            FlowChips(listOf("1M", "5M", "15M", "1H", "4H", "1D"), s.timeframe) { t -> upd { it.copy(timeframe = t) } }
        }
        Card {
            Label("Notifications")
            SwitchRow("Notify on WAIT results", s.notifyWait) { v -> upd { it.copy(notifyWait = v) } }
            SwitchRow("Sound alerts for signals", s.sound) { v -> upd { it.copy(sound = v) } }
            Spacer(Modifier.height(6.dp))
            Text("Signal cooldown: ${s.cooldownMin} min (same market/timeframe/direction is not notified twice)", fontSize = 13.sp)
            Slider(value = s.cooldownMin.toFloat(), onValueChange = { v -> upd { it.copy(cooldownMin = v.toInt()) } }, valueRange = 0f..60f, steps = 11)
        }
        Card {
            Label("Floating button position")
            Spacer(Modifier.height(6.dp))
            val dm = ctx.resources.displayMetrics
            val w = dm.widthPixels; val h = dm.heightPixels; val d = dm.density
            val m = (80 * d).toInt()
            FlowChips(listOf("Top right", "Middle right", "Bottom right", "Middle left", "Reset"), "") { p ->
                upd {
                    when (p) {
                        "Top right" -> it.copy(btnX = w - m, btnY = (h * 0.12).toInt())
                        "Middle right" -> it.copy(btnX = w - m, btnY = (h * 0.45).toInt())
                        "Bottom right" -> it.copy(btnX = w - m, btnY = (h * 0.75).toInt())
                        "Middle left" -> it.copy(btnX = (8 * d).toInt(), btnY = (h * 0.45).toInt())
                        else -> it.copy(btnX = -1, btnY = -1)
                    }
                }
            }
            Text("You can also drag the button anywhere. Long-press it to hide.", color = C.muted, fontSize = 11.sp)
        }
        Card {
            Label("Permissions")
            Spacer(Modifier.height(6.dp))
            PermRow("Display over other apps", overlayOk, "Grant", onOverlay)
            PermRow("Notifications", notifOk, "Grant", onNotif)
            PermRow("Screenshot (screen capture)", projection, "Asked on START", null)
            PermRow("Battery: unrestricted", null, "Open", onBattery)
            Text("Some phones (Xiaomi, Samsung, Oppo…) kill background apps. Set this app to 'Unrestricted' battery use if the button disappears.", color = C.muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun SwitchRow(t: String, v: Boolean, onChange: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(t, fontSize = 14.sp)
        Switch(v, onChange, colors = SwitchDefaults.colors(checkedTrackColor = C.buy, checkedThumbColor = Color.Black))
    }

@Composable
private fun PermRow(t: String, ok: Boolean?, action: String, onClick: (() -> Unit)?) =
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text(t, fontSize = 14.sp)
            Text(
                when (ok) { true -> "● Granted / active"; false -> "● Not granted"; null -> "● Recommended" },
                color = when (ok) { true -> C.buy; false -> C.sell; null -> C.wait }, fontSize = 11.sp
            )
        }
        if (onClick != null && ok != true) TextButton(onClick = onClick) { Text(action, color = C.info) }
        else if (onClick == null) Text(action, color = C.muted, fontSize = 11.sp)
    }

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun FlowChips(options: List<String>, selected: String, onPick: (String) -> Unit) =
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        options.forEach { o ->
            FilterChip(
                selected = o == selected, onClick = { onPick(o) }, label = { Text(o) },
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = C.buy, selectedLabelColor = Color.Black)
            )
        }
    }
