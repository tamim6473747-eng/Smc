package com.personal.smartmoneyai

import com.personal.smartmoneyai.model.AnalysisResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ScanState { IDLE, SCANNING, ANALYZING, SIGNAL_FOUND, WAIT }

/** Process-wide state shared by the service (writer) and the Compose UI (reader). */
object ScannerState {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running.asStateFlow()

    private val _scan = MutableStateFlow(ScanState.IDLE)
    val scan: StateFlow<ScanState> = _scan.asStateFlow()

    private val _projection = MutableStateFlow(false)
    val projectionActive: StateFlow<Boolean> = _projection.asStateFlow()

    private val _buttonVisible = MutableStateFlow(false)
    val buttonVisible: StateFlow<Boolean> = _buttonVisible.asStateFlow()

    private val _last = MutableStateFlow<AnalysisResult?>(null)
    val last: StateFlow<AnalysisResult?> = _last.asStateFlow()

    private val _message = MutableStateFlow("Scanner is off")
    val message: StateFlow<String> = _message.asStateFlow()

    fun setRunning(v: Boolean) { _running.value = v }
    fun setScan(v: ScanState) { _scan.value = v }
    fun setProjection(v: Boolean) { _projection.value = v }
    fun setButtonVisible(v: Boolean) { _buttonVisible.value = v }
    fun setLast(v: AnalysisResult) { _last.value = v }
    fun setMessage(v: String) { _message.value = v }
}
