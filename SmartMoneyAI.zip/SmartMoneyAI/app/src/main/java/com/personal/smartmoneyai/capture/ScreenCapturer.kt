package com.personal.smartmoneyai.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.view.WindowManager
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Holds ONE MediaProjection + VirtualDisplay for the life of the scanner (Android 14 allows
 * createVirtualDisplay only once per projection token and requires a registered callback).
 */
class ScreenCapturer(private val ctx: Context, private val onStopped: () -> Unit) {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var w = 0
    private var h = 0

    val active get() = projection != null

    /** Must be called AFTER startForeground(..., FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION). */
    fun start(resultCode: Int, data: Intent) {
        stop()
        val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val mp = mpm.getMediaProjection(resultCode, data)
        thread = HandlerThread("capture").also { it.start() }
        handler = Handler(thread!!.looper)
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                release()
                onStopped()
            }
        }, handler)

        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dpi = ctx.resources.displayMetrics.densityDpi
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            w = b.width(); h = b.height()
        } else {
            @Suppress("DEPRECATION") val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
            w = dm.widthPixels; h = dm.heightPixels
        }
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        display = mp.createVirtualDisplay(
            "smartmoney-capture", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        projection = mp
    }

    /**
     * Grabs a fresh frame. [beforeWait] runs after we armed the listener (use it to hide the
     * floating button so it does not appear in the screenshot, which also forces a new frame).
     */
    suspend fun capture(beforeWait: () -> Unit): Bitmap? {
        val r = reader ?: return null
        while (true) { (r.acquireLatestImage() ?: break).close() }
        val got = CompletableDeferred<Unit>()
        r.setOnImageAvailableListener({ got.complete(Unit) }, handler)
        beforeWait()
        withTimeoutOrNull(1200) { got.await() }
        r.setOnImageAvailableListener(null, null)
        val img = r.acquireLatestImage() ?: return null
        return try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * w
            val padded = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(plane.buffer)
            if (padded.width == w) padded else Bitmap.createBitmap(padded, 0, 0, w, h).also { padded.recycle() }
        } finally {
            img.close()
        }
    }

    fun release() {
        display?.release(); display = null
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
        projection = null
    }

    fun stop() {
        val p = projection
        release()
        try { p?.stop() } catch (_: Exception) {}
    }
}
