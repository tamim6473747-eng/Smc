package com.personal.smartmoneyai.notify

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.personal.smartmoneyai.MainActivity
import com.personal.smartmoneyai.R
import com.personal.smartmoneyai.model.AnalysisResult
import com.personal.smartmoneyai.model.Decision
import com.personal.smartmoneyai.service.ScannerService

class Notifier(private val ctx: Context) {
    companion object {
        const val CH_SERVICE = "scanner_service"
        const val CH_SOUND = "signals_sound"
        const val CH_SILENT = "signals_silent"
        const val ID_SERVICE = 1001
        const val ID_RESULT = 2001
    }

    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "Scanner running", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_SOUND, "Signals (sound)", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel(CH_SILENT, "Signals (silent)", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null); enableVibration(false)
            })
        }
    }

    private fun openApp() = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun serviceAction(action: String, code: Int) = PendingIntent.getService(
        ctx, code, Intent(ctx, ScannerService::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun serviceNotification(text: String): Notification =
        NotificationCompat.Builder(ctx, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_scanner)
            .setContentTitle("Smart Money AI scanner")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(openApp())
            .addAction(0, "Show/Hide button", serviceAction(ScannerService.ACTION_TOGGLE_BUTTON, 1))
            .addAction(0, "Stop", serviceAction(ScannerService.ACTION_STOP, 2))
            .build()

    fun updateService(text: String) {
        if (canPost()) nm.notify(ID_SERVICE, serviceNotification(text))
    }

    /** One fixed id: a new result replaces the old one instead of stacking duplicates. */
    fun postResult(r: AnalysisResult, sound: Boolean) {
        if (!canPost()) return
        val n = NotificationCompat.Builder(ctx, if (sound) CH_SOUND else CH_SILENT)
            .setSmallIcon(R.drawable.ic_scanner)
            .setContentTitle("SMART MONEY AI")
            .setSubText(SignalFormatter.title(r))
            .setContentText(SignalFormatter.short(r))
            .setStyle(NotificationCompat.BigTextStyle().bigText(SignalFormatter.body(r)))
            .setPriority(if (r.decision == Decision.BUY || r.decision == Decision.SELL) NotificationCompat.PRIORITY_HIGH else NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()
        nm.notify(ID_RESULT, n)
    }

    private fun canPost() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
}
