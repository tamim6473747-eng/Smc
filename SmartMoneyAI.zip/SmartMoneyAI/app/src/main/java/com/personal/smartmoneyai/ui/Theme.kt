package com.personal.smartmoneyai.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object C {
    val bg = Color(0xFF0B0D10)
    val card = Color(0xFF14181D)
    val line = Color(0xFF232932)
    val text = Color.White
    val muted = Color(0xFF8A94A3)
    val buy = Color(0xFF2BD576)
    val sell = Color(0xFFFF5252)
    val wait = Color(0xFFFFD54F)
    val info = Color(0xFF4FC3F7)
}

@Composable
fun SmcTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = C.bg, surface = C.card, primary = C.buy, onPrimary = Color.Black,
            onBackground = C.text, onSurface = C.text, secondary = C.info
        ),
        content = content
    )
}
