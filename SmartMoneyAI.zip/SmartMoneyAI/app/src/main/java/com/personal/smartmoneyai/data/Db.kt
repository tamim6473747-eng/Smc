package com.personal.smartmoneyai.data

import android.content.Context
import androidx.room.*
import com.personal.smartmoneyai.model.AnalysisResult
import com.personal.smartmoneyai.model.Decision
import com.personal.smartmoneyai.model.Grade
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "signals")
data class SignalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val time: Long,
    val market: String,
    val timeframe: String,
    val decision: String,
    val score: Int,
    val grade: String,
    val entryLow: Double?,
    val entryHigh: Double?,
    val stopLoss: Double?,
    val tp1: Double?,
    val tp2: Double?,
    val rr: Double?,
    val confirmations: String,
    val reasons: String
)

private const val SEP = "\u001F"

fun AnalysisResult.toEntity() = SignalEntity(
    time = timestamp, market = market, timeframe = timeframe, decision = decision.name, score = score,
    grade = grade.name, entryLow = entryLow, entryHigh = entryHigh, stopLoss = stopLoss, tp1 = takeProfit1,
    tp2 = takeProfit2, rr = riskReward, confirmations = confirmations.joinToString(SEP),
    reasons = reasons.joinToString(SEP)
)

fun SignalEntity.toResult() = AnalysisResult(
    decision = Decision.valueOf(decision), score = score, grade = Grade.valueOf(grade), market = market,
    timeframe = timeframe, entryLow = entryLow, entryHigh = entryHigh, stopLoss = stopLoss,
    takeProfit1 = tp1, takeProfit2 = tp2, riskReward = rr,
    confirmations = if (confirmations.isEmpty()) emptyList() else confirmations.split(SEP),
    reasons = if (reasons.isEmpty()) emptyList() else reasons.split(SEP), timestamp = time
)

@Dao
interface SignalDao {
    @Insert suspend fun insert(s: SignalEntity): Long

    @Query("SELECT * FROM signals ORDER BY time DESC LIMIT 300")
    fun observeAll(): Flow<List<SignalEntity>>

    @Query("DELETE FROM signals") suspend fun clear()

    @Query("SELECT * FROM signals WHERE decision = :decision AND market = :market AND timeframe = :tf ORDER BY time DESC LIMIT 1")
    suspend fun lastOf(decision: String, market: String, tf: String): SignalEntity?
}

@Database(entities = [SignalEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): SignalDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "smartmoney.db").build().also { inst = it }
        }
    }
}
