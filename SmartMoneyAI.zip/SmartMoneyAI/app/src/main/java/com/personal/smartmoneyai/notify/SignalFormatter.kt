package com.personal.smartmoneyai.notify

import com.personal.smartmoneyai.model.AnalysisResult
import com.personal.smartmoneyai.model.Decision
import java.util.Locale

object SignalFormatter {
    fun price(v: Double?): String = when {
        v == null -> "—"
        v >= 1000 -> String.format(Locale.US, "%,.2f", v)
        v >= 1 -> String.format(Locale.US, "%.4f", v)
        else -> String.format(Locale.US, "%.6f", v)
    }

    fun title(r: AnalysisResult) = when (r.decision) {
        Decision.BUY -> "🟢 BUY SIGNAL · ${r.score}/100"
        Decision.SELL -> "🔴 SELL SIGNAL · ${r.score}/100"
        Decision.WAIT -> "🟡 WAIT"
        Decision.UNABLE -> "⚪ UNABLE TO ANALYZE"
    }

    fun short(r: AnalysisResult): String = when (r.decision) {
        Decision.BUY, Decision.SELL ->
            "${r.market} ${r.timeframe} · Entry ${price(r.entryLow)}–${price(r.entryHigh)} · SL ${price(r.stopLoss)}"
        Decision.WAIT -> "No high-quality trading setup detected."
        Decision.UNABLE -> "Please provide a clearer chart."
    }

    fun body(r: AnalysisResult): String = buildString {
        when (r.decision) {
            Decision.BUY, Decision.SELL -> {
                appendLine("Market: ${r.market}")
                appendLine("Direction: ${r.decision.name}")
                appendLine("Timeframe: ${r.timeframe}")
                appendLine()
                appendLine("Entry Zone: ${price(r.entryLow)}–${price(r.entryHigh)}")
                appendLine("Stop Loss: ${price(r.stopLoss)}")
                appendLine("Take Profit 1: ${price(r.takeProfit1)}")
                appendLine("Take Profit 2: ${price(r.takeProfit2)}")
                appendLine()
                appendLine("SMC Confirmations:")
                r.confirmations.forEach { appendLine("✓ $it") }
                appendLine()
                appendLine("Confluence Score: ${r.score}/100 (${r.grade.label})")
                appendLine("Risk/Reward: 1:${String.format(Locale.US, "%.1f", r.riskReward ?: 0.0)}")
                appendLine()
                append("Score = technical confluence, not a win probability. Manual confirmation required; nothing is traded automatically.")
            }
            Decision.WAIT -> {
                appendLine("Market: ${r.market} · ${r.timeframe}")
                appendLine("No high-quality trading setup detected.")
                appendLine()
                appendLine("Reason:")
                r.reasons.distinct().forEach { appendLine("- $it") }
                append("\nConfluence ${r.score}/100")
            }
            Decision.UNABLE -> {
                appendLine("UNABLE TO ANALYZE — Please provide a clearer chart.")
                appendLine()
                appendLine("Reason:")
                r.reasons.forEach { appendLine("- $it") }
            }
        }
    }.trim()
}
