package com.personal.smartmoneyai.smc

import com.personal.smartmoneyai.model.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Rule-based Smart Money Concepts engine. Every detector has an explicit, documented rule.
 * The score is TECHNICAL CONFLUENCE only — it is not a win probability.
 */
data class Swing(val index: Int, val price: Double, val isHigh: Boolean)
data class Fvg(val bullish: Boolean, val low: Double, val high: Double, val index: Int, val filled: Boolean)
data class OrderBlock(val bullish: Boolean, val zone: Zone, val firstTouch: Int?, val invalidated: Boolean) {
    val mitigated get() = firstTouch != null
}
data class Sweep(val bullishSetup: Boolean, val level: Double, val extreme: Double, val index: Int)

data class SmcConfig(
    val minScore: Int = 75,
    val minRiskReward: Double = 1.5,
    val minCandles: Int = 30,
    val swingStrength: Int = 2,
    val eqTolAtr: Double = 0.15,
    val displacementAtr: Double = 1.5
)

class SmcEngine(private val cfg: SmcConfig = SmcConfig()) {

    // ---------- primitives ----------
    fun atr(c: List<Candle>, period: Int = 14): Double {
        if (c.size < 2) return 0.0
        val trs = (1 until c.size).map {
            max(c[it].high - c[it].low, max(abs(c[it].high - c[it - 1].close), abs(c[it].low - c[it - 1].close)))
        }
        return trs.takeLast(period).average()
    }

    /** Fractal swing: high strictly above [n] candles each side (confirmed only once n candles follow). */
    fun swings(c: List<Candle>): List<Swing> {
        val n = cfg.swingStrength
        val out = mutableListOf<Swing>()
        for (i in n until c.size - n) {
            val hi = c[i].high
            val lo = c[i].low
            if ((1..n).all { hi > c[i - it].high && hi >= c[i + it].high }) out += Swing(i, hi, true)
            if ((1..n).all { lo < c[i - it].low && lo <= c[i + it].low }) out += Swing(i, lo, false)
        }
        return out.sortedBy { it.index }
    }

    fun isDisplacement(c: List<Candle>, i: Int, atr: Double): Boolean {
        val k = c[i]
        if (atr <= 0 || k.range <= 0) return false
        return k.body >= cfg.displacementAtr * atr && k.body / k.range >= 0.6
    }

    fun fvgs(c: List<Candle>): List<Fvg> {
        val out = mutableListOf<Fvg>()
        for (i in 2 until c.size) {
            val a = c[i - 2]; val b = c[i]
            if (b.low > a.high) { // bullish gap
                val filled = (i + 1 until c.size).any { c[it].low <= a.high }
                out += Fvg(true, a.high, b.low, i - 1, filled)
            } else if (b.high < a.low) { // bearish gap
                val filled = (i + 1 until c.size).any { c[it].high >= a.low }
                out += Fvg(false, b.high, a.low, i - 1, filled)
            }
        }
        return out
    }

    // ---------- market structure ----------
    enum class Trend { UP, DOWN, RANGE }
    data class Structure(
        val trend: Trend,
        val labels: List<String>,        // HH/HL/LH/LL in order
        val bosIndex: Int?, val bosBullish: Boolean?,
        val chochIndex: Int?, val chochBullish: Boolean?
    )

    fun structure(c: List<Candle>, sw: List<Swing>): Structure {
        val highs = sw.filter { it.isHigh }
        val lows = sw.filter { !it.isHigh }
        val labels = mutableListOf<String>()
        for (k in 1 until highs.size) labels += if (highs[k].price > highs[k - 1].price) "HH" else "LH"
        for (k in 1 until lows.size) labels += if (lows[k].price > lows[k - 1].price) "HL" else "LL"

        // Walk candle closes against confirmed swings to find BOS / CHoCH.
        var trend = Trend.RANGE
        var lastHigh: Swing? = null
        var lastLow: Swing? = null
        var bosI: Int? = null; var bosB: Boolean? = null
        var chI: Int? = null; var chB: Boolean? = null
        val confirmAt = cfg.swingStrength
        var si = 0
        for (i in c.indices) {
            while (si < sw.size && sw[si].index + confirmAt <= i) {
                if (sw[si].isHigh) lastHigh = sw[si] else lastLow = sw[si]
                si++
            }
            val close = c[i].close
            val h = lastHigh; val l = lastLow
            if (h != null && close > h.price) {
                if (trend == Trend.DOWN) { chI = i; chB = true } else if (trend == Trend.UP) { bosI = i; bosB = true }
                trend = Trend.UP
                lastHigh = null // consumed
            } else if (l != null && close < l.price) {
                if (trend == Trend.UP) { chI = i; chB = false } else if (trend == Trend.DOWN) { bosI = i; bosB = false }
                trend = Trend.DOWN
                lastLow = null
            }
        }
        return Structure(trend, labels, bosI, bosB, chI, chB)
    }

    // ---------- liquidity ----------
    /** Clusters of swing highs/lows within tolerance => equal highs / equal lows. */
    fun equalLevels(sw: List<Swing>, atr: Double, highs: Boolean): List<Double> {
        val pts = sw.filter { it.isHigh == highs }.map { it.price }.sorted()
        val tol = atr * cfg.eqTolAtr
        val out = mutableListOf<Double>()
        for (i in 1 until pts.size) if (pts[i] - pts[i - 1] <= tol) out += (pts[i] + pts[i - 1]) / 2
        return out
    }

    /**
     * Sweep rule: within the last [lookback] candles a wick pierces a prior confirmed swing level
     * and the SAME candle (or the next) closes back on the original side.
     * Sell-side sweep (bullish setup): low < swing low, close > swing low.
     */
    fun sweeps(c: List<Candle>, sw: List<Swing>, lookback: Int = 12): List<Sweep> {
        val out = mutableListOf<Sweep>()
        val start = max(0, c.size - lookback)
        for (i in start until c.size) {
            for (s in sw) {
                if (s.index + cfg.swingStrength >= i) continue
                val k = c[i]
                val next = c.getOrNull(i + 1)
                if (!s.isHigh && k.low < s.price) {
                    val back = k.close > s.price || (next != null && next.close > s.price)
                    if (back) out += Sweep(true, s.price, k.low, i)
                }
                if (s.isHigh && k.high > s.price) {
                    val back = k.close < s.price || (next != null && next.close < s.price)
                    if (back) out += Sweep(false, s.price, k.high, i)
                }
            }
        }
        return out.distinctBy { it.index to it.bullishSetup }
    }

    // ---------- order blocks ----------
    /** OB = last opposite-colour candle before a displacement candle that breaks structure. */
    fun orderBlocks(c: List<Candle>, atr: Double): List<OrderBlock> {
        val out = mutableListOf<OrderBlock>()
        for (i in 1 until c.size) {
            if (!isDisplacement(c, i, atr)) continue
            val d = c[i]
            val prior = (i - 1 downTo max(0, i - 6)).firstOrNull {
                if (d.bullish) c[it].bearish else c[it].bullish
            } ?: continue
            val ob = c[prior]
            val zone = Zone(ob.low, ob.high, prior, if (d.bullish) "Bullish OB" else "Bearish OB")
            val after = (i + 1 until c.size).map { c[it] }
            val invalid = if (d.bullish) after.any { it.close < ob.low } else after.any { it.close > ob.high }
            val firstTouch = (i + 1 until c.size).firstOrNull { if (d.bullish) c[it].low <= ob.high else c[it].high >= ob.low }
            out += OrderBlock(d.bullish, zone, firstTouch, invalid)
        }
        return out
    }

    // ---------- analysis ----------
    fun analyze(chart: ChartData): AnalysisResult {
        val market = chart.market ?: "Unknown market"
        val tf = chart.timeframe ?: "Unknown TF"
        val c = chart.candles
        if (c.size < cfg.minCandles) {
            return AnalysisResult(Decision.UNABLE, 0, Grade.NONE, market, tf,
                reasons = listOf("Only ${c.size} candles could be read (need ${cfg.minCandles}). Please provide a clearer chart."))
        }
        val atr = atr(c)
        val sw = swings(c)
        val st = structure(c, sw)
        val fv = fvgs(c)
        val obs = orderBlocks(c, atr)
        val sweeps = sweeps(c, sw)
        val last = c.last()
        val price = last.close
        val reasons = mutableListOf<String>()

        val buy = evaluate(true, c, sw, st, fv, obs, sweeps, atr, price)
        val sell = evaluate(false, c, sw, st, fv, obs, sweeps, atr, price)
        val best = if (buy.score >= sell.score) buy else sell
        val other = if (best === buy) sell else buy

        // Conflicting: both sides scoring high => refuse.
        if (other.score >= cfg.minScore - 10 && best.score < 90) reasons += "Conflicting bullish/bearish evidence."
        reasons += best.missing
        if (best.score < cfg.minScore) reasons += "Confluence ${best.score}/100 is below the minimum ${cfg.minScore}."

        val rr = best.rr
        val rrOk = rr != null && rr >= cfg.minRiskReward
        if (best.entry != null && !rrOk) reasons += "Risk/reward ${rr?.let { "%.2f".format(it) } ?: "n/a"} below ${cfg.minRiskReward}."

        val valid = best.score >= cfg.minScore && best.gatesOk && rrOk && reasons.none { it.startsWith("Conflicting") }
        val grade = when {
            !valid -> Grade.NONE
            best.score >= 85 -> Grade.HIGH
            else -> Grade.POTENTIAL
        }
        if (!valid) {
            return AnalysisResult(Decision.WAIT, best.score, Grade.NONE, market, tf,
                reasons = reasons.ifEmpty { listOf("Confluence ${best.score}/100 below minimum ${cfg.minScore}.") },
                breakdown = best.breakdown)
        }
        val e = best.entry!!
        return AnalysisResult(
            decision = if (best.bullish) Decision.BUY else Decision.SELL,
            score = best.score, grade = grade, market = market, timeframe = tf,
            entryLow = e.low, entryHigh = e.high, stopLoss = best.sl,
            takeProfit1 = best.tp1, takeProfit2 = best.tp2, riskReward = rr,
            confirmations = best.confirmations, breakdown = best.breakdown
        )
    }

    private data class Eval(
        val bullish: Boolean, val score: Int, val breakdown: Map<String, Int>,
        val confirmations: List<String>, val missing: List<String>, val gatesOk: Boolean,
        val entry: Zone?, val sl: Double?, val tp1: Double?, val tp2: Double?, val rr: Double?
    )

    private fun evaluate(
        bull: Boolean, c: List<Candle>, sw: List<Swing>, st: Structure,
        fv: List<Fvg>, obs: List<OrderBlock>, sweeps: List<Sweep>, atr: Double, price: Double
    ): Eval {
        val conf = mutableListOf<String>()
        val miss = mutableListOf<String>()
        val bd = linkedMapOf<String, Int>()
        val side = if (bull) "bullish" else "bearish"
        val last = c.last()
        val lookFrom = max(0, c.size - 20)

        // Market structure (20): recent CHoCH/MSS in direction = 20, BOS in direction = 12.
        val recentCh = st.chochIndex != null && st.chochBullish == bull && st.chochIndex >= lookFrom
        val recentBos = st.bosIndex != null && st.bosBullish == bull && st.bosIndex >= lookFrom
        val ms = when { recentCh -> 20; recentBos -> 12; else -> 0 }
        bd["Market Structure"] = ms
        if (recentCh) conf += "${side.replaceFirstChar { it.uppercase() }} CHoCH / MSS"
        else if (recentBos) conf += "${side.replaceFirstChar { it.uppercase() }} BOS"
        else miss += "No confirmed market structure shift ($side)."

        // Liquidity (20): matching sweep in last 12 candles = 14, +6 if it swept equal highs/lows.
        // Deepest sweep in direction = the real liquidity grab (also defines the stop).
        val sw0 = sweeps.filter { it.bullishSetup == bull }.let { l -> if (bull) l.minByOrNull { it.extreme } else l.maxByOrNull { it.extreme } }
        var liq = 0
        if (sw0 != null) {
            liq = 14
            val eq = equalLevels(sw, atr, highs = !bull)
            if (eq.any { abs(it - sw0.level) <= atr * cfg.eqTolAtr * 2 }) liq += 6
            conf += if (bull) "Sell-side liquidity sweep" else "Buy-side liquidity sweep"
        } else miss += "Liquidity sweep not confirmed."
        bd["Liquidity"] = liq

        // Displacement is a gate for structure shift.
        val dispIdx = (lookFrom until c.size).filter { isDisplacement(c, it, atr) && c[it].bullish == bull }
        val hasDisp = dispIdx.isNotEmpty()
        if (hasDisp) conf += "${side.replaceFirstChar { it.uppercase() }} displacement" else miss += "No strong $side displacement."

        // Order block (15): valid (not invalidated) OB in direction.
        val ob = obs.filter { it.bullish == bull && !it.invalidated && it.zone.startIndex >= lookFrom - 10 }
            .maxByOrNull { it.zone.startIndex }
        // Fresh = untouched, or being mitigated for the first time within the last 3 candles (that IS the entry).
        val freshOb = ob != null && (ob.firstTouch == null || ob.firstTouch >= c.size - 3)
        bd["Order Block"] = if (ob != null) (if (freshOb) 15 else 8) else 0
        if (ob != null) conf += "Valid $side order block" else miss += "No valid $side order block."

        // FVG (15): unfilled FVG in direction, or partially filled where price now sits.
        val gap = fv.filter { it.bullish == bull && it.index >= lookFrom - 5 }
            .filter { !it.filled || price in it.low..it.high }
            .maxByOrNull { it.index }
        bd["Fair Value Gap"] = if (gap != null) 15 else 0
        if (gap != null) conf += "Valid $side FVG" else miss += "No valid $side FVG."

        // Higher-timeframe alignment (15): not scorable from one chart. Never faked.
        bd["Higher Timeframe Alignment"] = 0
        miss += "Higher-timeframe data not visible — alignment not scored."

        // Entry zone. FVG entries use the half nearest the origin (50% "consequent encroachment" to the edge).
        val gapZone = gap?.let { if (bull) Zone(it.low, (it.low + it.high) / 2, it.index, "FVG") else Zone((it.low + it.high) / 2, it.high, it.index, "FVG") }
        val zones = listOfNotNull(ob?.zone, gapZone)
        val entry: Zone? = when {
            zones.size == 2 -> {
                val lo = max(zones[0].low, zones[1].low); val hi = min(zones[0].high, zones[1].high)
                if (lo < hi) Zone(lo, hi, zones.maxOf { it.startIndex }, "OB+FVG")
                else zones.minByOrNull { z -> if (z.contains(price)) 0.0 else min(abs(z.low - price), abs(z.high - price)) }
            }
            zones.size == 1 -> zones[0]
            else -> null
        }

        // Premium/discount: buys only in discount (below 50% of dealing range), sells in premium.
        val hi = c.takeLast(60).maxOf { it.high }
        val lo = c.takeLast(60).minOf { it.low }
        val eqPrice = (hi + lo) / 2
        val pdOk = entry != null && (if (bull) entry.mid <= eqPrice else entry.mid >= eqPrice)
        if (entry != null && pdOk) conf += if (bull) "Entry in discount zone" else "Entry in premium zone"
        else if (entry != null) miss += "Entry zone is in the wrong half of the range (${if (bull) "premium" else "discount"})."

        // Entry confirmation (15): price has returned into zone and last candle closes in direction.
        var ec = 0
        if (entry != null) {
            val touched = last.low <= entry.high && last.high >= entry.low
            val recentTouch = c.takeLast(3).any { it.low <= entry.high && it.high >= entry.low }
            val dirClose = if (bull) last.close > last.open && last.close > entry.low else last.close < last.open && last.close < entry.high
            if (touched && dirClose) ec = 15 else if (recentTouch && dirClose) ec = 10
        }
        bd["Entry Confirmation"] = ec
        if (ec > 0) conf += "Entry confirmation candle in zone" else miss += "Entry confirmation missing."

        val score = bd.values.sum()

        // Risk model — real prices only, derived from detected structure.
        var sl: Double? = null; var tp1: Double? = null; var tp2: Double? = null; var rr: Double? = null
        if (entry != null) {
            val buffer = atr * 0.1
            val extreme = sw0?.extreme
            sl = if (bull) min(entry.low, extreme ?: entry.low) - buffer else max(entry.high, extreme ?: entry.high) + buffer
            val e = price.coerceIn(entry.low, entry.high) // realistic fill: current price if inside the zone
            val risk = abs(e - sl)
            // Targets are real opposing swing levels (liquidity pools) that pay at least minRiskReward.
            val minReward = cfg.minRiskReward * risk
            val targets = if (bull) sw.filter { it.isHigh && it.price - e >= minReward }.map { it.price }.sorted()
            else sw.filter { !it.isHigh && e - it.price >= minReward }.map { it.price }.sortedDescending()
            tp1 = targets.getOrNull(0)
            tp2 = targets.getOrNull(1) ?: tp1?.let { if (bull) it + (it - e) * 0.5 else it - (e - it) * 0.5 }
            if (tp1 != null && risk > 0) rr = abs(tp1 - e) / risk
            if (tp1 == null) miss += "No liquidity target offers risk/reward of at least ${cfg.minRiskReward}."
        }
        val gates = (recentCh || recentBos) && sw0 != null && hasDisp && entry != null && pdOk && ec > 0
        return Eval(bull, score, bd, conf, miss, gates, entry, sl, tp1, tp2, rr)
    }
}
