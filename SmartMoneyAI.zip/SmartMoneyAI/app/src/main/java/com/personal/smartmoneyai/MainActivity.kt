package com.personal.smartmoneyai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.personal.smartmoneyai.capture.CapturePermissionActivity
import com.personal.smartmoneyai.service.ScannerService
import com.personal.smartmoneyai.ui.AppRoot

class MainActivity : ComponentActivity() {
    /** Bumped in onResume so permission status rows re-read the system state. */
    private var resumeTick by mutableIntStateOf(0)

    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (!granted) toast("Notifications are off — you will not see signals. Enable them in system settings.")
        launchCaptureConsent()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppRoot(
                tick = resumeTick,
                onStart = ::startScanner,
                onStop = { startService(Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_STOP)) },
                onToggleButton = { startService(Intent(this, ScannerService::class.java).setAction(ScannerService.ACTION_TOGGLE_BUTTON)) },
                onOpenOverlaySettings = ::openOverlaySettings,
                onOpenBatterySettings = {
                    startActivity(Intent(AndroidSettings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                },
                onRequestNotifications = {
                    if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            )
        }
    }

    override fun onResume() { super.onResume(); resumeTick++ }

    private fun openOverlaySettings() {
        startActivity(Intent(AndroidSettings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    private fun startScanner() {
        if (!AndroidSettings.canDrawOverlays(this)) {
            toast("Allow 'Display over other apps' for Smart Money AI, then press START again.")
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        launchCaptureConsent()
    }

    private fun launchCaptureConsent() {
        startActivity(Intent(this, CapturePermissionActivity::class.java))
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
