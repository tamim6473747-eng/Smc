package com.personal.smartmoneyai.service

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.provider.Settings as AndroidSettings
import com.personal.smartmoneyai.ScanState
import com.personal.smartmoneyai.ScannerState
import com.personal.smartmoneyai.capture.CapturePermissionActivity
import com.personal.smartmoneyai.capture.ScreenCapturer
import com.personal.smartmoneyai.data.AppDb
import com.personal.smartmoneyai.data.Settings
import com.personal.smartmoneyai.data.SettingsStore
import com.personal.smartmoneyai.data.toEntity
import com.personal.smartmoneyai.model.AnalysisResult
import com.personal.smartmoneyai.model.Decision
import com.personal.smartmoneyai.model.Grade
import com.personal.smartmoneyai.notify.Notifier
import com.personal.smartmoneyai.overlay.FloatingButton
import com.personal.smartmoneyai.smc.SmcConfig
import com.personal.smartmoneyai.smc.SmcEngine
import com.personal.smartmoneyai.vision.ChartRecognizer
import com.personal.smartmoneyai.vision.PixelChartRecognizer
import com.personal.smartmoneyai.vision.Recognition
import kotlinx.coroutines.*

class ScannerService : Service() {
    companion object {
        const val ACTION_START = "smai.START"
        const val ACTION_STOP = "smai.STOP"
        const val ACTION_TOGGLE_BUTTON = "smai.TOGGLE"
        const val ACTION_PERMISSION_DENIED = "smai.DENIED"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val ui = Handler(android.os.Looper.getMainLooper())
    private lateinit var notifier: Notifier
    private lateinit var settingsStore: SettingsStore
    private lateinit var db: AppDb
    private lateinit var capturer: ScreenCapturer
    private lateinit var button: FloatingButton
    private val recognizer: ChartRecognizer = PixelChartRecognizer() // swap point for a future CV model
    @Volatile private var settings = Settings()
    private var scanning = false
    private var resetJob: Job? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        notifier = Notifier(this)
        settingsStore = SettingsStore(this)
        db = AppDb.get(this)
        capturer = ScreenCapturer(this) {
            ui.post {
                ScannerState.setProjection(false)
                ScannerState.setMessage("Screen-capture permission ended. Tap the floating button to grant it again.")
                notifier.updateService("Capture permission ended — tap the floating button to renew")
            }
        }
        button = FloatingButton(this, onTap = ::onButtonTap, onLongPress = { setButtonVisible(false) }, onMoved = { x, y ->
            scope.launch { settingsStore.update { it.copy(btnX = x, btnY = y) } }
        })
        scope.launch {
            settingsStore.flow.collect { s ->
                settings = s
                if (s.btnX >= 0 && s.btnY >= 0) button.moveTo(s.btnX, s.btnY)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> start(intent)
            ACTION_STOP -> stopAll()
            ACTION_TOGGLE_BUTTON -> setButtonVisible(!button.shown)
            ACTION_PERMISSION_DENIED -> {
                ScannerState.setMessage("Screen capture was not allowed. Scanning needs that permission.")
                if (!ScannerState.running.value) stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun start(intent: Intent) {
        // Android 14: the mediaProjection foreground service must be running BEFORE getMediaProjection().
        val n = notifier.serviceNotification("Ready — open a chart and tap the floating button")
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(Notifier.ID_SERVICE, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(Notifier.ID_SERVICE, n)

        val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        @Suppress("DEPRECATION") val data: Intent? = intent.getParcelableExtra(EXTRA_DATA)
        if (data == null) { stopAll(); return }
        try {
            capturer.start(code, data)
        } catch (e: Exception) {
            ScannerState.setMessage("Could not start screen capture: ${e.message}")
            stopAll(); return
        }
        ScannerState.setRunning(true)
        ScannerState.setProjection(true)
        ScannerState.setMessage("Scanner ready. Open your chart and tap the floating button.")
        setButtonVisible(true)
    }

    private fun setButtonVisible(v: Boolean) {
        if (v) {
            if (!AndroidSettings.canDrawOverlays(this)) {
                ScannerState.setMessage("Overlay permission missing — enable 'Display over other apps'.")
                return
            }
            val dm = resources.displayMetrics
            val s = settings
            val x = if (s.btnX >= 0) s.btnX else dm.widthPixels - (80 * dm.density).toInt()
            val y = if (s.btnY >= 0) s.btnY else (dm.heightPixels * 0.4).toInt()
            button.show(x, y)
            button.render(ScanState.IDLE)
        } else button.hide()
        ScannerState.setButtonVisible(button.shown)
    }

    private fun setScan(s: ScanState, color: Int? = null) {
        ScannerState.setScan(s)
        button.render(s, color)
    }

    private fun onButtonTap() {
        if (scanning) return // prevent simultaneous scans
        if (!capturer.active) {
            ScannerState.setMessage("Capture permission needed — approve the dialog.")
            startActivity(Intent(this, CapturePermissionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        }
        scanning = true
        resetJob?.cancel()
        scope.launch {
            try { runScan() } finally { scanning = false }
        }
    }

    private suspend fun runScan() {
        setScan(ScanState.SCANNING)
        ScannerState.setMessage("Capturing screen…")
        val bmp = withContext(Dispatchers.Main) {
            capturer.capture { button.setInvisibleForCapture(true) }
        }
        button.setInvisibleForCapture(false)
        if (bmp == null) {
            finish(AnalysisResult(Decision.UNABLE, 0, Grade.NONE, "Unknown market", "Unknown",
                reasons = listOf("Screen capture returned no image.")))
            return
        }
        setScan(ScanState.ANALYZING)
        ScannerState.setMessage("Analyzing chart…")
        val s = settings
        val result: AnalysisResult = withContext(Dispatchers.Default) {
            when (val rec = recognizer.recognize(bmp)) {
                is Recognition.Failure -> AnalysisResult(Decision.UNABLE, 0, Grade.NONE, "Unknown market", s.timeframe,
                    reasons = listOf(rec.reason))
                is Recognition.Success -> {
                    val tf = rec.chart.timeframe ?: "${s.timeframe} (from your settings; not visible on chart)"
                    val chart = rec.chart.copy(timeframe = tf)
                    SmcEngine(SmcConfig(minScore = s.minScore)).analyze(chart)
                }
            }
        }
        bmp.recycle()
        finish(result)
    }

    private suspend fun finish(r: AnalysisResult) {
        val s = settings
        var suppressed = false
        if (r.decision == Decision.BUY || r.decision == Decision.SELL) {
            val prev = db.dao().lastOf(r.decision.name, r.market, r.timeframe)
            if (prev != null && r.timestamp - prev.time < s.cooldownMin * 60_000L) suppressed = true
        }
        withContext(Dispatchers.IO) { db.dao().insert(r.toEntity()) }
        ScannerState.setLast(r)

        val isSignal = r.decision == Decision.BUY || r.decision == Decision.SELL
        when {
            suppressed -> ScannerState.setMessage("Same ${r.decision} signal already sent within ${s.cooldownMin} min — notification skipped.")
            isSignal -> { notifier.postResult(r, s.sound); ScannerState.setMessage("${r.decision} setup found: score ${r.score}/100") }
            r.decision == Decision.WAIT -> { if (s.notifyWait) notifier.postResult(r, false); ScannerState.setMessage("WAIT — no high-quality setup") }
            else -> { notifier.postResult(r, false); ScannerState.setMessage("Unable to analyze — clearer chart needed") }
        }
        notifier.updateService(ScannerState.message.value)

        when {
            isSignal -> setScan(ScanState.SIGNAL_FOUND, if (r.decision == Decision.BUY) 0xFF2BD576.toInt() else 0xFFFF5252.toInt())
            else -> setScan(ScanState.WAIT)
        }
        resetJob = scope.launch { delay(6000); setScan(ScanState.IDLE) }
    }

    private fun stopAll() {
        resetJob?.cancel()
        button.hide()
        capturer.stop()
        ScannerState.setRunning(false)
        ScannerState.setProjection(false)
        ScannerState.setButtonVisible(false)
        ScannerState.setScan(ScanState.IDLE)
        ScannerState.setMessage("Scanner is off")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        button.hide()
        capturer.stop()
        ScannerState.setRunning(false)
        ScannerState.setButtonVisible(false)
        super.onDestroy()
    }
}
