package com.personal.smartmoneyai.model

import kotlin.math.abs

data class Candle(
    val index: Int,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double? = null
) {
    val bullish get() = close > open
    val bearish get() = close < open
    val body get() = abs(close - open)
    val range get() = high - low
}

enum class Decision { BUY, SELL, WAIT, UNABLE }

enum class Grade(val label: String) {
    NONE("No setup"),
    POTENTIAL("Potential Setup"),
    HIGH("High-Confluence Setup")
}

/** Output of chart recognition. Only [candles] that were really read from pixels are included. */
data class ChartData(
    val candles: List<Candle>,
    val market: String?,
    val timeframe: String?,
    val confidence: Double,
    val notes: List<String>
)

data class Zone(val low: Double, val high: Double, val startIndex: Int, val label: String) {
    val mid get() = (low + high) / 2
    fun contains(p: Double) = p in low..high
}

data class AnalysisResult(
    val decision: Decision,
    val score: Int,
    val grade: Grade,
    val market: String,
    val timeframe: String,
    val entryLow: Double? = null,
    val entryHigh: Double? = null,
    val stopLoss: Double? = null,
    val takeProfit1: Double? = null,
    val takeProfit2: Double? = null,
    val riskReward: Double? = null,
    val confirmations: List<String> = emptyList(),
    val reasons: List<String> = emptyList(),
    val breakdown: Map<String, Int> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis()
)
